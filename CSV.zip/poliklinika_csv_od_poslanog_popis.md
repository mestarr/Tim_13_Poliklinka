# CSV paket za bazu Poliklinika

CSV datoteke su izrađene iz poslanih fileova `poliklinika_mysql_ddl.sql` i `poliklinika_seed_inserts.sql`.

| # | Tablica | Broj kolona | Broj redaka | CSV file |
|---:|---|---:|---:|---|
| 1 | `pacijent` | 14 | 200 | `pacijent.csv` |
| 2 | `odjel` | 6 | 30 | `odjel.csv` |
| 3 | `ordinacija` | 7 | 45 | `ordinacija.csv` |
| 4 | `specijalizacija` | 6 | 30 | `specijalizacija.csv` |
| 5 | `zaposlenik` | 12 | 60 | `zaposlenik.csv` |
| 6 | `usluga` | 9 | 124 | `usluga.csv` |
| 7 | `cijena_usluge` | 10 | 124 | `cijena_usluge.csv` |
| 8 | `raspored_zaposlenika` | 8 | 720 | `raspored_zaposlenika.csv` |
| 9 | `termin_pacijenta` | 11 | 300 | `termin_pacijenta.csv` |
| 10 | `termin_pacijenta_usluga` | 5 | 381 | `termin_pacijenta_usluga.csv` |
| 11 | `pregled` | 10 | 185 | `pregled.csv` |
| 12 | `pregled_usluga` | 10 | 232 | `pregled_usluga.csv` |
| 13 | `dijagnoza` | 6 | 25 | `dijagnoza.csv` |
| 14 | `pregled_dijagnoza` | 6 | 340 | `pregled_dijagnoza.csv` |
| 15 | `tip_nalaza` | 6 | 5 | `tip_nalaza.csv` |
| 16 | `nalaz` | 11 | 112 | `nalaz.csv` |
| 17 | `laboratorijski_parametar` | 7 | 12 | `laboratorijski_parametar.csv` |
| 18 | `laboratorijski_rezultat` | 13 | 375 | `laboratorijski_rezultat.csv` |
| 19 | `terapija` | 10 | 127 | `terapija.csv` |
| 20 | `preporuceni_lijek` | 9 | 170 | `preporuceni_lijek.csv` |
| 21 | `nacin_placanja` | 5 | 5 | `nacin_placanja.csv` |
| 22 | `racun` | 15 | 185 | `racun.csv` |
| 23 | `stavka_racuna` | 14 | 232 | `stavka_racuna.csv` |
| 24 | `uplata` | 9 | 132 | `uplata.csv` |
